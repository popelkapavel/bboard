﻿namespace bboard
{
    partial class fMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
      this.mMain = new System.Windows.Forms.MenuStrip();
      this.eRadius = new System.Windows.Forms.TextBox();
      this.timer = new System.Windows.Forms.Timer(this.components);
      this.chColor = new System.Windows.Forms.CheckBox();
      this.bColor = new System.Windows.Forms.Button();
      this.panel = new System.Windows.Forms.Panel();
      this.bBlue = new System.Windows.Forms.Button();
      this.button8 = new System.Windows.Forms.Button();
      this.button7 = new System.Windows.Forms.Button();
      this.button5 = new System.Windows.Forms.Button();
      this.button4 = new System.Windows.Forms.Button();
      this.button6 = new System.Windows.Forms.Button();
      this.bColorGr1 = new System.Windows.Forms.Button();
      this.bColorGr3 = new System.Windows.Forms.Button();
      this.bColorGr2 = new System.Windows.Forms.Button();
      this.bGY = new System.Windows.Forms.Button();
      this.bGreen = new System.Windows.Forms.Button();
      this.bRed = new System.Windows.Forms.Button();
      this.bColorGr4 = new System.Windows.Forms.Button();
      this.bYellow = new System.Windows.Forms.Button();
      this.button1 = new System.Windows.Forms.Button();
      this.bCyan = new System.Windows.Forms.Button();
      this.bWhite = new System.Windows.Forms.Button();
      this.toolTip = new System.Windows.Forms.ToolTip(this.components);
      this.br5 = new System.Windows.Forms.Button();
      this.br4 = new System.Windows.Forms.Button();
      this.br3 = new System.Windows.Forms.Button();
      this.br2 = new System.Windows.Forms.Button();
      this.br1 = new System.Windows.Forms.Button();
      this.bh4 = new System.Windows.Forms.Button();
      this.bh2 = new System.Windows.Forms.Button();
      this.miFile = new System.Windows.Forms.ToolStripMenuItem();
      this.miFileNew = new System.Windows.Forms.ToolStripMenuItem();
      this.miFileOpen = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
      this.miFileSave = new System.Windows.Forms.ToolStripMenuItem();
      this.miSaveAs = new System.Windows.Forms.ToolStripMenuItem();
      this.miExport = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.miPage = new System.Windows.Forms.ToolStripMenuItem();
      this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
      this.miFileExit = new System.Windows.Forms.ToolStripMenuItem();
      this.miHill = new System.Windows.Forms.ToolStripMenuItem();
      this.miHillCone = new System.Windows.Forms.ToolStripMenuItem();
      this.miHillSphere = new System.Windows.Forms.ToolStripMenuItem();
      this.miHillCylinder = new System.Windows.Forms.ToolStripMenuItem();
      this.sigmaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.nailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.miEdit = new System.Windows.Forms.ToolStripMenuItem();
      this.miEditUndo = new System.Windows.Forms.ToolStripMenuItem();
      this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
      this.miEditClear = new System.Windows.Forms.ToolStripMenuItem();
      this.miEditInvert = new System.Windows.Forms.ToolStripMenuItem();
      this.miEditBlur = new System.Windows.Forms.ToolStripMenuItem();
      this.layersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
      this.miAutoSnap = new System.Windows.Forms.ToolStripMenuItem();
      this.miCombine = new System.Windows.Forms.ToolStripMenuItem();
      this.miCombineMax = new System.Windows.Forms.ToolStripMenuItem();
      this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.miCombineAvg = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
      this.miHillCombineNone = new System.Windows.Forms.ToolStripMenuItem();
      this.miColor = new System.Windows.Forms.ToolStripMenuItem();
      this.miHillWhite = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.rotateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.rGBCMYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.rBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.bBW = new System.Windows.Forms.Button();
      this.bh1 = new System.Windows.Forms.Button();
      this.bClear = new System.Windows.Forms.Button();
      this.bh3 = new System.Windows.Forms.Button();
      this.bh5 = new System.Windows.Forms.Button();
      this.mMain.SuspendLayout();
      this.panel.SuspendLayout();
      this.SuspendLayout();
      // 
      // mMain
      // 
      this.mMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miFile,
            this.miHill,
            this.miEdit,
            this.miCombine,
            this.miColor});
      this.mMain.Location = new System.Drawing.Point(0, 0);
      this.mMain.Name = "mMain";
      this.mMain.Size = new System.Drawing.Size(268, 24);
      this.mMain.TabIndex = 0;
      this.mMain.Text = "menuStrip1";
      // 
      // eRadius
      // 
      this.eRadius.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.eRadius.Location = new System.Drawing.Point(146, 79);
      this.eRadius.Name = "eRadius";
      this.eRadius.Size = new System.Drawing.Size(29, 20);
      this.eRadius.TabIndex = 4;
      this.eRadius.Text = "15";
      // 
      // timer
      // 
      this.timer.Enabled = true;
      this.timer.Tick += new System.EventHandler(this.timer_Tick);
      // 
      // chColor
      // 
      this.chColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.chColor.AutoSize = true;
      this.chColor.BackColor = System.Drawing.Color.White;
      this.chColor.Location = new System.Drawing.Point(254, 75);
      this.chColor.Name = "chColor";
      this.chColor.Size = new System.Drawing.Size(15, 14);
      this.chColor.TabIndex = 13;
      this.chColor.UseVisualStyleBackColor = false;
      this.chColor.CheckedChanged += new System.EventHandler(this.chColor_CheckedChanged);
      // 
      // bColor
      // 
      this.bColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColor.BackColor = System.Drawing.Color.Black;
      this.bColor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColor.Location = new System.Drawing.Point(192, 71);
      this.bColor.Name = "bColor";
      this.bColor.Size = new System.Drawing.Size(61, 35);
      this.bColor.TabIndex = 15;
      this.bColor.UseVisualStyleBackColor = false;
      this.bColor.Click += new System.EventHandler(this.bColor_Click2);
      // 
      // panel
      // 
      this.panel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.panel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panel.Controls.Add(this.bBlue);
      this.panel.Controls.Add(this.button8);
      this.panel.Controls.Add(this.button7);
      this.panel.Controls.Add(this.button5);
      this.panel.Controls.Add(this.button4);
      this.panel.Controls.Add(this.button6);
      this.panel.Controls.Add(this.bColorGr1);
      this.panel.Controls.Add(this.bColorGr3);
      this.panel.Controls.Add(this.bColorGr2);
      this.panel.Controls.Add(this.bGY);
      this.panel.Controls.Add(this.bGreen);
      this.panel.Controls.Add(this.bRed);
      this.panel.Controls.Add(this.bColorGr4);
      this.panel.Controls.Add(this.bYellow);
      this.panel.Controls.Add(this.button1);
      this.panel.Controls.Add(this.bCyan);
      this.panel.Controls.Add(this.bWhite);
      this.panel.Controls.Add(this.br5);
      this.panel.Controls.Add(this.br4);
      this.panel.Controls.Add(this.br3);
      this.panel.Controls.Add(this.br2);
      this.panel.Controls.Add(this.br1);
      this.panel.Controls.Add(this.bh4);
      this.panel.Controls.Add(this.bh2);
      this.panel.Controls.Add(this.mMain);
      this.panel.Controls.Add(this.bColor);
      this.panel.Controls.Add(this.bBW);
      this.panel.Controls.Add(this.bh1);
      this.panel.Controls.Add(this.chColor);
      this.panel.Controls.Add(this.bClear);
      this.panel.Controls.Add(this.bh3);
      this.panel.Controls.Add(this.bh5);
      this.panel.Controls.Add(this.eRadius);
      this.panel.Location = new System.Drawing.Point(451, 0);
      this.panel.Name = "panel";
      this.panel.Size = new System.Drawing.Size(272, 113);
      this.panel.TabIndex = 21;
      this.panel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_MouseUp);
      // 
      // bBlue
      // 
      this.bBlue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bBlue.BackColor = System.Drawing.Color.Blue;
      this.bBlue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bBlue.Location = new System.Drawing.Point(226, 47);
      this.bBlue.Name = "bBlue";
      this.bBlue.Size = new System.Drawing.Size(20, 20);
      this.bBlue.TabIndex = 44;
      this.bBlue.Tag = "5";
      this.bBlue.UseVisualStyleBackColor = false;
      this.bBlue.Click += new System.EventHandler(this.bColor_Click);
      // 
      // button8
      // 
      this.button8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
      this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button8.Location = new System.Drawing.Point(153, 27);
      this.button8.Name = "button8";
      this.button8.Size = new System.Drawing.Size(10, 20);
      this.button8.TabIndex = 39;
      this.button8.Tag = "";
      this.button8.UseVisualStyleBackColor = false;
      this.button8.Click += new System.EventHandler(this.bColor_Click);
      // 
      // button7
      // 
      this.button7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
      this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button7.Location = new System.Drawing.Point(143, 27);
      this.button7.Name = "button7";
      this.button7.Size = new System.Drawing.Size(10, 20);
      this.button7.TabIndex = 38;
      this.button7.Tag = "";
      this.button7.UseVisualStyleBackColor = false;
      this.button7.Click += new System.EventHandler(this.bColor_Click);
      // 
      // button5
      // 
      this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
      this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button5.Location = new System.Drawing.Point(173, 27);
      this.button5.Name = "button5";
      this.button5.Size = new System.Drawing.Size(10, 20);
      this.button5.TabIndex = 37;
      this.button5.Tag = "";
      this.button5.UseVisualStyleBackColor = false;
      this.button5.Click += new System.EventHandler(this.bColor_Click);
      // 
      // button4
      // 
      this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
      this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button4.Location = new System.Drawing.Point(163, 27);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(10, 20);
      this.button4.TabIndex = 40;
      this.button4.Tag = "";
      this.button4.UseVisualStyleBackColor = false;
      this.button4.Click += new System.EventHandler(this.bColor_Click);
      // 
      // button6
      // 
      this.button6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
      this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button6.Location = new System.Drawing.Point(133, 27);
      this.button6.Name = "button6";
      this.button6.Size = new System.Drawing.Size(10, 20);
      this.button6.TabIndex = 43;
      this.button6.Tag = "";
      this.button6.UseVisualStyleBackColor = false;
      this.button6.Click += new System.EventHandler(this.bColor_Click);
      // 
      // bColorGr1
      // 
      this.bColorGr1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
      this.bColorGr1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr1.Location = new System.Drawing.Point(123, 47);
      this.bColorGr1.Name = "bColorGr1";
      this.bColorGr1.Size = new System.Drawing.Size(20, 20);
      this.bColorGr1.TabIndex = 42;
      this.bColorGr1.Tag = "";
      this.bColorGr1.UseVisualStyleBackColor = false;
      this.bColorGr1.Click += new System.EventHandler(this.bColor_Click);
      // 
      // bColorGr3
      // 
      this.bColorGr3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
      this.bColorGr3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr3.Location = new System.Drawing.Point(163, 47);
      this.bColorGr3.Name = "bColorGr3";
      this.bColorGr3.Size = new System.Drawing.Size(20, 20);
      this.bColorGr3.TabIndex = 41;
      this.bColorGr3.Tag = "";
      this.bColorGr3.UseVisualStyleBackColor = false;
      this.bColorGr3.Click += new System.EventHandler(this.bColor_Click);
      // 
      // bColorGr2
      // 
      this.bColorGr2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
      this.bColorGr2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr2.Location = new System.Drawing.Point(143, 47);
      this.bColorGr2.Name = "bColorGr2";
      this.bColorGr2.Size = new System.Drawing.Size(20, 20);
      this.bColorGr2.TabIndex = 36;
      this.bColorGr2.Tag = "";
      this.bColorGr2.UseVisualStyleBackColor = false;
      this.bColorGr2.Click += new System.EventHandler(this.bColor_Click);
      // 
      // bGY
      // 
      this.bGY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bGY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
      this.bGY.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bGY.Location = new System.Drawing.Point(123, 27);
      this.bGY.Name = "bGY";
      this.bGY.Size = new System.Drawing.Size(10, 20);
      this.bGY.TabIndex = 34;
      this.bGY.Tag = "";
      this.bGY.UseVisualStyleBackColor = false;
      this.bGY.Click += new System.EventHandler(this.bColor_Click);
      // 
      // bGreen
      // 
      this.bGreen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bGreen.BackColor = System.Drawing.Color.Lime;
      this.bGreen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bGreen.Location = new System.Drawing.Point(205, 27);
      this.bGreen.Name = "bGreen";
      this.bGreen.Size = new System.Drawing.Size(20, 20);
      this.bGreen.TabIndex = 35;
      this.bGreen.Tag = "3";
      this.bGreen.UseVisualStyleBackColor = false;
      this.bGreen.Click += new System.EventHandler(this.bColor_Click);
      // 
      // bRed
      // 
      this.bRed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bRed.BackColor = System.Drawing.Color.Red;
      this.bRed.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bRed.Location = new System.Drawing.Point(247, 27);
      this.bRed.Name = "bRed";
      this.bRed.Size = new System.Drawing.Size(20, 20);
      this.bRed.TabIndex = 33;
      this.bRed.Tag = "1";
      this.bRed.UseVisualStyleBackColor = false;
      this.bRed.Click += new System.EventHandler(this.bColor_Click);
      // 
      // bColorGr4
      // 
      this.bColorGr4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr4.BackColor = System.Drawing.Color.Gray;
      this.bColorGr4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr4.Location = new System.Drawing.Point(184, 47);
      this.bColorGr4.Name = "bColorGr4";
      this.bColorGr4.Size = new System.Drawing.Size(20, 20);
      this.bColorGr4.TabIndex = 32;
      this.bColorGr4.Tag = "8";
      this.bColorGr4.UseVisualStyleBackColor = false;
      this.bColorGr4.Click += new System.EventHandler(this.bColor_Click);
      // 
      // bYellow
      // 
      this.bYellow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bYellow.BackColor = System.Drawing.Color.Yellow;
      this.bYellow.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bYellow.Location = new System.Drawing.Point(226, 27);
      this.bYellow.Name = "bYellow";
      this.bYellow.Size = new System.Drawing.Size(20, 20);
      this.bYellow.TabIndex = 29;
      this.bYellow.Tag = "2";
      this.bYellow.UseVisualStyleBackColor = false;
      this.bYellow.Click += new System.EventHandler(this.bColor_Click);
      // 
      // button1
      // 
      this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button1.BackColor = System.Drawing.Color.Magenta;
      this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button1.Location = new System.Drawing.Point(247, 47);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(20, 20);
      this.button1.TabIndex = 31;
      this.button1.Tag = "6";
      this.button1.UseVisualStyleBackColor = false;
      this.button1.Click += new System.EventHandler(this.bColor_Click);
      // 
      // bCyan
      // 
      this.bCyan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bCyan.BackColor = System.Drawing.Color.Cyan;
      this.bCyan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bCyan.Location = new System.Drawing.Point(205, 47);
      this.bCyan.Name = "bCyan";
      this.bCyan.Size = new System.Drawing.Size(20, 20);
      this.bCyan.TabIndex = 30;
      this.bCyan.Tag = "4";
      this.bCyan.UseVisualStyleBackColor = false;
      this.bCyan.Click += new System.EventHandler(this.bColor_Click);
      // 
      // bWhite
      // 
      this.bWhite.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bWhite.BackColor = System.Drawing.Color.White;
      this.bWhite.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bWhite.Location = new System.Drawing.Point(184, 27);
      this.bWhite.Name = "bWhite";
      this.bWhite.Size = new System.Drawing.Size(20, 20);
      this.bWhite.TabIndex = 28;
      this.bWhite.Tag = "7";
      this.bWhite.UseVisualStyleBackColor = false;
      this.bWhite.Click += new System.EventHandler(this.bColor_Click);
      // 
      // br5
      // 
      this.br5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.br5.BackColor = System.Drawing.SystemColors.Control;
      this.br5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.br5.Image = global::bboard.Properties.Resources.s5;
      this.br5.Location = new System.Drawing.Point(94, 48);
      this.br5.Name = "br5";
      this.br5.Size = new System.Drawing.Size(20, 20);
      this.br5.TabIndex = 27;
      this.br5.Tag = "25";
      this.br5.UseVisualStyleBackColor = false;
      this.br5.Click += new System.EventHandler(this.bRadius_Click);
      // 
      // br4
      // 
      this.br4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.br4.BackColor = System.Drawing.SystemColors.Control;
      this.br4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.br4.Image = global::bboard.Properties.Resources.s4;
      this.br4.Location = new System.Drawing.Point(73, 48);
      this.br4.Name = "br4";
      this.br4.Size = new System.Drawing.Size(20, 20);
      this.br4.TabIndex = 26;
      this.br4.Tag = "20";
      this.br4.UseVisualStyleBackColor = false;
      this.br4.Click += new System.EventHandler(this.bRadius_Click);
      // 
      // br3
      // 
      this.br3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.br3.BackColor = System.Drawing.SystemColors.Control;
      this.br3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.br3.Image = global::bboard.Properties.Resources.s3;
      this.br3.Location = new System.Drawing.Point(52, 48);
      this.br3.Name = "br3";
      this.br3.Size = new System.Drawing.Size(20, 20);
      this.br3.TabIndex = 25;
      this.br3.Tag = "15";
      this.br3.UseVisualStyleBackColor = false;
      this.br3.Click += new System.EventHandler(this.bRadius_Click);
      // 
      // br2
      // 
      this.br2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.br2.BackColor = System.Drawing.SystemColors.Control;
      this.br2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.br2.Image = global::bboard.Properties.Resources.s2;
      this.br2.Location = new System.Drawing.Point(31, 48);
      this.br2.Name = "br2";
      this.br2.Size = new System.Drawing.Size(20, 20);
      this.br2.TabIndex = 24;
      this.br2.Tag = "10";
      this.br2.UseVisualStyleBackColor = false;
      this.br2.Click += new System.EventHandler(this.bRadius_Click);
      // 
      // br1
      // 
      this.br1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.br1.BackColor = System.Drawing.SystemColors.Control;
      this.br1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.br1.Image = global::bboard.Properties.Resources.s1;
      this.br1.Location = new System.Drawing.Point(10, 48);
      this.br1.Name = "br1";
      this.br1.Size = new System.Drawing.Size(20, 20);
      this.br1.TabIndex = 23;
      this.br1.Tag = "5";
      this.br1.UseVisualStyleBackColor = false;
      this.br1.Click += new System.EventHandler(this.bRadius_Click);
      // 
      // bh4
      // 
      this.bh4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bh4.BackColor = System.Drawing.SystemColors.Control;
      this.bh4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bh4.Image = global::bboard.Properties.Resources.h4;
      this.bh4.Location = new System.Drawing.Point(73, 27);
      this.bh4.Name = "bh4";
      this.bh4.Size = new System.Drawing.Size(20, 20);
      this.bh4.TabIndex = 22;
      this.bh4.Tag = "210";
      this.bh4.UseVisualStyleBackColor = false;
      this.bh4.Click += new System.EventHandler(this.bHeight_Click);
      // 
      // bh2
      // 
      this.bh2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bh2.BackColor = System.Drawing.SystemColors.Control;
      this.bh2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bh2.Image = global::bboard.Properties.Resources.h2;
      this.bh2.Location = new System.Drawing.Point(31, 27);
      this.bh2.Name = "bh2";
      this.bh2.Size = new System.Drawing.Size(20, 20);
      this.bh2.TabIndex = 21;
      this.bh2.Tag = "130";
      this.bh2.UseVisualStyleBackColor = false;
      this.bh2.Click += new System.EventHandler(this.bHeight_Click);
      // 
      // miFile
      // 
      this.miFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miFileNew,
            this.miFileOpen,
            this.toolStripSeparator6,
            this.miFileSave,
            this.miSaveAs,
            this.miExport,
            this.toolStripSeparator1,
            this.miPage,
            this.printToolStripMenuItem,
            this.toolStripSeparator7,
            this.miFileExit});
      this.miFile.Image = global::bboard.Properties.Resources._new;
      this.miFile.Name = "miFile";
      this.miFile.Size = new System.Drawing.Size(41, 20);
      this.miFile.Text = "&F";
      this.miFile.ToolTipText = "File";
      // 
      // miFileNew
      // 
      this.miFileNew.Image = global::bboard.Properties.Resources._new;
      this.miFileNew.Name = "miFileNew";
      this.miFileNew.Size = new System.Drawing.Size(152, 22);
      this.miFileNew.Tag = "new";
      this.miFileNew.Text = "&New";
      this.miFileNew.Click += new System.EventHandler(this.miFile_Click);
      // 
      // miFileOpen
      // 
      this.miFileOpen.Image = global::bboard.Properties.Resources.open;
      this.miFileOpen.Name = "miFileOpen";
      this.miFileOpen.Size = new System.Drawing.Size(152, 22);
      this.miFileOpen.Tag = "open";
      this.miFileOpen.Text = "&Open";
      this.miFileOpen.Click += new System.EventHandler(this.miFile_Click);
      // 
      // toolStripSeparator6
      // 
      this.toolStripSeparator6.Name = "toolStripSeparator6";
      this.toolStripSeparator6.Size = new System.Drawing.Size(149, 6);
      // 
      // miFileSave
      // 
      this.miFileSave.Image = global::bboard.Properties.Resources.save;
      this.miFileSave.Name = "miFileSave";
      this.miFileSave.Size = new System.Drawing.Size(152, 22);
      this.miFileSave.Tag = "save";
      this.miFileSave.Text = "&Save";
      this.miFileSave.Click += new System.EventHandler(this.miFile_Click);
      // 
      // miSaveAs
      // 
      this.miSaveAs.Image = global::bboard.Properties.Resources.saveas;
      this.miSaveAs.Name = "miSaveAs";
      this.miSaveAs.Size = new System.Drawing.Size(152, 22);
      this.miSaveAs.Tag = "saveas";
      this.miSaveAs.Text = "S&ave as ...";
      this.miSaveAs.Click += new System.EventHandler(this.miFile_Click);
      // 
      // miExport
      // 
      this.miExport.Image = global::bboard.Properties.Resources.export;
      this.miExport.Name = "miExport";
      this.miExport.Size = new System.Drawing.Size(152, 22);
      this.miExport.Tag = "export";
      this.miExport.Text = "&Export ...";
      this.miExport.Click += new System.EventHandler(this.miFile_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
      // 
      // miPage
      // 
      this.miPage.Image = global::bboard.Properties.Resources.page;
      this.miPage.Name = "miPage";
      this.miPage.Size = new System.Drawing.Size(152, 22);
      this.miPage.Tag = "page";
      this.miPage.Text = "Pa&ge ...";
      this.miPage.Click += new System.EventHandler(this.miFile_Click);
      // 
      // printToolStripMenuItem
      // 
      this.printToolStripMenuItem.Image = global::bboard.Properties.Resources.print;
      this.printToolStripMenuItem.Name = "printToolStripMenuItem";
      this.printToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
      this.printToolStripMenuItem.Tag = "print";
      this.printToolStripMenuItem.Text = "&Print ...";
      this.printToolStripMenuItem.Click += new System.EventHandler(this.miFile_Click);
      // 
      // toolStripSeparator7
      // 
      this.toolStripSeparator7.Name = "toolStripSeparator7";
      this.toolStripSeparator7.Size = new System.Drawing.Size(149, 6);
      // 
      // miFileExit
      // 
      this.miFileExit.Image = global::bboard.Properties.Resources.close;
      this.miFileExit.Name = "miFileExit";
      this.miFileExit.Size = new System.Drawing.Size(152, 22);
      this.miFileExit.Tag = "exit";
      this.miFileExit.Text = "&Exit";
      this.miFileExit.Click += new System.EventHandler(this.miFile_Click);
      // 
      // miHill
      // 
      this.miHill.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miHillCone,
            this.miHillSphere,
            this.miHillCylinder,
            this.sigmaToolStripMenuItem,
            this.nailToolStripMenuItem});
      this.miHill.Image = global::bboard.Properties.Resources.cone;
      this.miHill.Name = "miHill";
      this.miHill.Size = new System.Drawing.Size(44, 20);
      this.miHill.Text = "&H";
      this.miHill.ToolTipText = "Hill";
      // 
      // miHillCone
      // 
      this.miHillCone.Image = global::bboard.Properties.Resources.cone;
      this.miHillCone.Name = "miHillCone";
      this.miHillCone.Size = new System.Drawing.Size(118, 22);
      this.miHillCone.Tag = "cone";
      this.miHillCone.Text = "&Cone";
      this.miHillCone.Click += new System.EventHandler(this.miHill_Click);
      // 
      // miHillSphere
      // 
      this.miHillSphere.Image = global::bboard.Properties.Resources.sphere;
      this.miHillSphere.Name = "miHillSphere";
      this.miHillSphere.Size = new System.Drawing.Size(118, 22);
      this.miHillSphere.Tag = "sphere";
      this.miHillSphere.Text = "&Sphere";
      this.miHillSphere.Click += new System.EventHandler(this.miHill_Click);
      // 
      // miHillCylinder
      // 
      this.miHillCylinder.Image = global::bboard.Properties.Resources.cylinder;
      this.miHillCylinder.Name = "miHillCylinder";
      this.miHillCylinder.Size = new System.Drawing.Size(118, 22);
      this.miHillCylinder.Tag = "cyl";
      this.miHillCylinder.Text = "Cy&linder";
      this.miHillCylinder.Click += new System.EventHandler(this.miHill_Click);
      // 
      // sigmaToolStripMenuItem
      // 
      this.sigmaToolStripMenuItem.Image = global::bboard.Properties.Resources.sigma;
      this.sigmaToolStripMenuItem.Name = "sigmaToolStripMenuItem";
      this.sigmaToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
      this.sigmaToolStripMenuItem.Tag = "sigma";
      this.sigmaToolStripMenuItem.Text = "Si&gma";
      this.sigmaToolStripMenuItem.Click += new System.EventHandler(this.miHill_Click);
      // 
      // nailToolStripMenuItem
      // 
      this.nailToolStripMenuItem.Image = global::bboard.Properties.Resources.nail;
      this.nailToolStripMenuItem.Name = "nailToolStripMenuItem";
      this.nailToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
      this.nailToolStripMenuItem.Tag = "nail";
      this.nailToolStripMenuItem.Text = "&Nail";
      this.nailToolStripMenuItem.Click += new System.EventHandler(this.miHill_Click);
      // 
      // miEdit
      // 
      this.miEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miEditUndo,
            this.redoToolStripMenuItem,
            this.toolStripSeparator3,
            this.miEditClear,
            this.miEditInvert,
            this.miEditBlur,
            this.layersToolStripMenuItem,
            this.toolStripSeparator5,
            this.miAutoSnap});
      this.miEdit.Image = global::bboard.Properties.Resources.clear;
      this.miEdit.Name = "miEdit";
      this.miEdit.Size = new System.Drawing.Size(41, 20);
      this.miEdit.Text = "&E";
      this.miEdit.ToolTipText = "Edit";
      // 
      // miEditUndo
      // 
      this.miEditUndo.Image = global::bboard.Properties.Resources.undo;
      this.miEditUndo.Name = "miEditUndo";
      this.miEditUndo.Size = new System.Drawing.Size(129, 22);
      this.miEditUndo.Tag = "undo";
      this.miEditUndo.Text = "&Undo";
      this.miEditUndo.Click += new System.EventHandler(this.miEdit_Click);
      // 
      // redoToolStripMenuItem
      // 
      this.redoToolStripMenuItem.Image = global::bboard.Properties.Resources.redo;
      this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
      this.redoToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
      this.redoToolStripMenuItem.Tag = "redo";
      this.redoToolStripMenuItem.Text = "&Redo";
      this.redoToolStripMenuItem.Click += new System.EventHandler(this.miEdit_Click);
      // 
      // toolStripSeparator3
      // 
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new System.Drawing.Size(126, 6);
      // 
      // miEditClear
      // 
      this.miEditClear.Image = global::bboard.Properties.Resources.clear;
      this.miEditClear.Name = "miEditClear";
      this.miEditClear.Size = new System.Drawing.Size(129, 22);
      this.miEditClear.Tag = "clear";
      this.miEditClear.Text = "&Clear";
      this.miEditClear.Click += new System.EventHandler(this.miEdit_Click);
      // 
      // miEditInvert
      // 
      this.miEditInvert.Image = global::bboard.Properties.Resources.invert;
      this.miEditInvert.Name = "miEditInvert";
      this.miEditInvert.Size = new System.Drawing.Size(129, 22);
      this.miEditInvert.Tag = "invert";
      this.miEditInvert.Text = "&Invert";
      this.miEditInvert.Click += new System.EventHandler(this.miEdit_Click);
      // 
      // miEditBlur
      // 
      this.miEditBlur.Image = global::bboard.Properties.Resources.blur;
      this.miEditBlur.Name = "miEditBlur";
      this.miEditBlur.Size = new System.Drawing.Size(129, 22);
      this.miEditBlur.Tag = "blur";
      this.miEditBlur.Text = "&Blur";
      this.miEditBlur.Click += new System.EventHandler(this.miEdit_Click);
      // 
      // layersToolStripMenuItem
      // 
      this.layersToolStripMenuItem.Image = global::bboard.Properties.Resources.layers;
      this.layersToolStripMenuItem.Name = "layersToolStripMenuItem";
      this.layersToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
      this.layersToolStripMenuItem.Tag = "layers";
      this.layersToolStripMenuItem.Text = "Layers";
      this.layersToolStripMenuItem.Click += new System.EventHandler(this.miEdit_Click);
      // 
      // toolStripSeparator5
      // 
      this.toolStripSeparator5.Name = "toolStripSeparator5";
      this.toolStripSeparator5.Size = new System.Drawing.Size(126, 6);
      // 
      // miAutoSnap
      // 
      this.miAutoSnap.Image = global::bboard.Properties.Resources.snap;
      this.miAutoSnap.Name = "miAutoSnap";
      this.miAutoSnap.Size = new System.Drawing.Size(129, 22);
      this.miAutoSnap.Text = "&Auto Snap";
      this.miAutoSnap.Click += new System.EventHandler(this.miAutoSnap_Click);
      // 
      // miCombine
      // 
      this.miCombine.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miCombineMax,
            this.addToolStripMenuItem,
            this.miCombineAvg,
            this.toolStripSeparator4,
            this.miHillCombineNone});
      this.miCombine.Image = global::bboard.Properties.Resources.max;
      this.miCombine.Name = "miCombine";
      this.miCombine.Size = new System.Drawing.Size(43, 20);
      this.miCombine.Text = "&A";
      this.miCombine.ToolTipText = "Combine";
      // 
      // miCombineMax
      // 
      this.miCombineMax.Image = global::bboard.Properties.Resources.max;
      this.miCombineMax.Name = "miCombineMax";
      this.miCombineMax.Size = new System.Drawing.Size(103, 22);
      this.miCombineMax.Tag = "1";
      this.miCombineMax.Text = "Ma&x";
      this.miCombineMax.Click += new System.EventHandler(this.miCombine_Click);
      // 
      // addToolStripMenuItem
      // 
      this.addToolStripMenuItem.Image = global::bboard.Properties.Resources.mult;
      this.addToolStripMenuItem.Name = "addToolStripMenuItem";
      this.addToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
      this.addToolStripMenuItem.Tag = "3";
      this.addToolStripMenuItem.Text = "Mul&t";
      this.addToolStripMenuItem.Click += new System.EventHandler(this.miCombine_Click);
      // 
      // miCombineAvg
      // 
      this.miCombineAvg.Image = global::bboard.Properties.Resources.add;
      this.miCombineAvg.Name = "miCombineAvg";
      this.miCombineAvg.Size = new System.Drawing.Size(103, 22);
      this.miCombineAvg.Tag = "5";
      this.miCombineAvg.Text = "&Add";
      this.miCombineAvg.Click += new System.EventHandler(this.miCombine_Click);
      // 
      // toolStripSeparator4
      // 
      this.toolStripSeparator4.Name = "toolStripSeparator4";
      this.toolStripSeparator4.Size = new System.Drawing.Size(100, 6);
      // 
      // miHillCombineNone
      // 
      this.miHillCombineNone.Image = global::bboard.Properties.Resources.color;
      this.miHillCombineNone.Name = "miHillCombineNone";
      this.miHillCombineNone.Size = new System.Drawing.Size(103, 22);
      this.miHillCombineNone.Tag = "0";
      this.miHillCombineNone.Text = "Non&e";
      this.miHillCombineNone.Click += new System.EventHandler(this.miCombine_Click);
      // 
      // miColor
      // 
      this.miColor.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miHillWhite,
            this.toolStripSeparator2,
            this.rotateToolStripMenuItem,
            this.rGBCMYToolStripMenuItem,
            this.rBToolStripMenuItem});
      this.miColor.Image = global::bboard.Properties.Resources.white;
      this.miColor.Name = "miColor";
      this.miColor.Size = new System.Drawing.Size(43, 20);
      this.miColor.Text = "&C";
      this.miColor.ToolTipText = "Color";
      // 
      // miHillWhite
      // 
      this.miHillWhite.Image = global::bboard.Properties.Resources.white;
      this.miHillWhite.Name = "miHillWhite";
      this.miHillWhite.Size = new System.Drawing.Size(149, 22);
      this.miHillWhite.Text = "&White";
      this.miHillWhite.Click += new System.EventHandler(this.miWhite_Click);
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(146, 6);
      // 
      // rotateToolStripMenuItem
      // 
      this.rotateToolStripMenuItem.Image = global::bboard.Properties.Resources.rgb2brg;
      this.rotateToolStripMenuItem.Name = "rotateToolStripMenuItem";
      this.rotateToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
      this.rotateToolStripMenuItem.Tag = "rotate";
      this.rotateToolStripMenuItem.Text = "Rotate";
      this.rotateToolStripMenuItem.Click += new System.EventHandler(this.miMColor_Click);
      // 
      // rGBCMYToolStripMenuItem
      // 
      this.rGBCMYToolStripMenuItem.Image = global::bboard.Properties.Resources.rgb2cmy;
      this.rGBCMYToolStripMenuItem.Name = "rGBCMYToolStripMenuItem";
      this.rGBCMYToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
      this.rGBCMYToolStripMenuItem.Tag = "rgb2cmy";
      this.rGBCMYToolStripMenuItem.Text = "RGB <-> CMY";
      this.rGBCMYToolStripMenuItem.Click += new System.EventHandler(this.miMColor_Click);
      // 
      // rBToolStripMenuItem
      // 
      this.rBToolStripMenuItem.Image = global::bboard.Properties.Resources.rgb2bgr;
      this.rBToolStripMenuItem.Name = "rBToolStripMenuItem";
      this.rBToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
      this.rBToolStripMenuItem.Tag = "rxb";
      this.rBToolStripMenuItem.Text = "R <-> B";
      this.rBToolStripMenuItem.Click += new System.EventHandler(this.miMColor_Click);
      // 
      // bBW
      // 
      this.bBW.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bBW.BackColor = System.Drawing.SystemColors.Control;
      this.bBW.Image = global::bboard.Properties.Resources.bw;
      this.bBW.Location = new System.Drawing.Point(63, 71);
      this.bBW.Name = "bBW";
      this.bBW.Size = new System.Drawing.Size(54, 28);
      this.bBW.TabIndex = 20;
      this.bBW.Tag = "255";
      this.toolTip.SetToolTip(this.bBW, "Remove colors");
      this.bBW.UseVisualStyleBackColor = false;
      this.bBW.Click += new System.EventHandler(this.bBW_Click);
      // 
      // bh1
      // 
      this.bh1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bh1.BackColor = System.Drawing.SystemColors.Control;
      this.bh1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bh1.Image = global::bboard.Properties.Resources.h1;
      this.bh1.Location = new System.Drawing.Point(10, 27);
      this.bh1.Name = "bh1";
      this.bh1.Size = new System.Drawing.Size(20, 20);
      this.bh1.TabIndex = 18;
      this.bh1.Tag = "85";
      this.bh1.UseVisualStyleBackColor = false;
      this.bh1.Click += new System.EventHandler(this.bHeight_Click);
      // 
      // bClear
      // 
      this.bClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bClear.BackColor = System.Drawing.SystemColors.Control;
      this.bClear.Image = global::bboard.Properties.Resources.clear;
      this.bClear.Location = new System.Drawing.Point(9, 71);
      this.bClear.Name = "bClear";
      this.bClear.Size = new System.Drawing.Size(52, 28);
      this.bClear.TabIndex = 19;
      this.bClear.Tag = "255";
      this.toolTip.SetToolTip(this.bClear, "Clear");
      this.bClear.UseVisualStyleBackColor = false;
      this.bClear.Click += new System.EventHandler(this.bClear_Click);
      // 
      // bh3
      // 
      this.bh3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bh3.BackColor = System.Drawing.SystemColors.Control;
      this.bh3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bh3.Image = global::bboard.Properties.Resources.h3;
      this.bh3.Location = new System.Drawing.Point(52, 27);
      this.bh3.Name = "bh3";
      this.bh3.Size = new System.Drawing.Size(20, 20);
      this.bh3.TabIndex = 17;
      this.bh3.Tag = "170";
      this.bh3.UseVisualStyleBackColor = false;
      this.bh3.Click += new System.EventHandler(this.bHeight_Click);
      // 
      // bh5
      // 
      this.bh5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bh5.BackColor = System.Drawing.SystemColors.Control;
      this.bh5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bh5.Image = global::bboard.Properties.Resources.h5;
      this.bh5.Location = new System.Drawing.Point(94, 27);
      this.bh5.Name = "bh5";
      this.bh5.Size = new System.Drawing.Size(20, 20);
      this.bh5.TabIndex = 16;
      this.bh5.Tag = "255";
      this.bh5.UseVisualStyleBackColor = false;
      this.bh5.Click += new System.EventHandler(this.bHeight_Click);
      // 
      // fMain
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(723, 514);
      this.Controls.Add(this.panel);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MainMenuStrip = this.mMain;
      this.Name = "fMain";
      this.Text = "BlackBoard";
      this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fMain_MouseDown);
      this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.fMain_MouseMove);
      this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.fMain_MouseUp);
      this.Resize += new System.EventHandler(this.fMain_Resize);
      this.mMain.ResumeLayout(false);
      this.mMain.PerformLayout();
      this.panel.ResumeLayout(false);
      this.panel.PerformLayout();
      this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuStrip mMain;
        private System.Windows.Forms.ToolStripMenuItem miFile;
        private System.Windows.Forms.ToolStripMenuItem miFileOpen;
        private System.Windows.Forms.ToolStripMenuItem miFileSave;
        private System.Windows.Forms.ToolStripMenuItem miFileExit;
        private System.Windows.Forms.ToolStripMenuItem miEdit;
        private System.Windows.Forms.ToolStripMenuItem miEditClear;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem miEditInvert;
        private System.Windows.Forms.ToolStripMenuItem miEditUndo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem miEditBlur;
        private System.Windows.Forms.TextBox eRadius;
        private System.Windows.Forms.ToolStripMenuItem miHill;
        private System.Windows.Forms.ToolStripMenuItem miHillSphere;
        private System.Windows.Forms.ToolStripMenuItem miHillCone;
        private System.Windows.Forms.ToolStripMenuItem miHillCylinder;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.CheckBox chColor;
        private System.Windows.Forms.Button bColor;
        private System.Windows.Forms.Button bh5;
        private System.Windows.Forms.Button bh3;
        private System.Windows.Forms.Button bh1;
        private System.Windows.Forms.Button bClear;
        private System.Windows.Forms.Button bBW;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Button bh2;
        private System.Windows.Forms.Button bh4;
        private System.Windows.Forms.Button br1;
        private System.Windows.Forms.Button br2;
        private System.Windows.Forms.Button br3;
        private System.Windows.Forms.Button br5;
        private System.Windows.Forms.Button br4;
        private System.Windows.Forms.ToolStripMenuItem nailToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem miAutoSnap;
        private System.Windows.Forms.ToolStripMenuItem miCombine;
        private System.Windows.Forms.ToolStripMenuItem miCombineMax;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miHillCombineNone;
        private System.Windows.Forms.Button bBlue;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button bColorGr1;
        private System.Windows.Forms.Button bColorGr3;
        private System.Windows.Forms.Button bColorGr2;
        private System.Windows.Forms.Button bGY;
        private System.Windows.Forms.Button bGreen;
        private System.Windows.Forms.Button bRed;
        private System.Windows.Forms.Button bColorGr4;
        private System.Windows.Forms.Button bYellow;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button bCyan;
        private System.Windows.Forms.Button bWhite;
        private System.Windows.Forms.ToolStripMenuItem miSaveAs;
        private System.Windows.Forms.ToolStripMenuItem miFileNew;
    private System.Windows.Forms.ToolStripMenuItem sigmaToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem miCombineAvg;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
    private System.Windows.Forms.ToolStripMenuItem miColor;
    private System.Windows.Forms.ToolStripMenuItem rotateToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem rGBCMYToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem rBToolStripMenuItem;
    private System.Windows.Forms.ToolTip toolTip;
    private System.Windows.Forms.ToolStripMenuItem miHillWhite;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem layersToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem miExport;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
    private System.Windows.Forms.ToolStripMenuItem miPage;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
    private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
  }
}

